<?php
 $ERROR_TEXT = "503 Service unavailable    ";
 $ERROR_DESCRIPTION = "
      The server is temporarily unable to service your request due to maintenance
      downtime or capacity problems. Please try again later. <br />
      <br />
      <br />
  ";

 include ( "header.php");
?>
