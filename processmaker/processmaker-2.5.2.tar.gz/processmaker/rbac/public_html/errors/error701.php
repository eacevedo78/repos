<?php
 $ERROR_TEXT = "701 workspace not available    ";
 $ERROR_DESCRIPTION = "You have specified a workspace not available in this server. <br>
      Please review your URL and try it again.<br />
      <br />
  ";
  
 include ( "header.php");
?>