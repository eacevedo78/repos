Needs Fixing
============

1. Fix formatting of dbprhead/dbprrow...its a little off
   (Anybody care?)

2. ct-lib placeholders do not work with TDS 7.0+.  To fix
   this requires either an SQL parser or API modification,
   because the library has to determine the SQL datatype
   of the placeholder variable.
